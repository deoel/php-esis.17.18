<?php 

	header('Location: ..');

?>