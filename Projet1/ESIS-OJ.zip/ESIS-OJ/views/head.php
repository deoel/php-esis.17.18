<div class="head-group">
	<div class="head">
		<h1>ESIS-OJ</h1>
		<p>
			<a href="today.php">Today</a>|
			<a href="all.php">All</a>|
			<a href="new.php">New</a>|
			<a href="top10.php">Top10</a>|
			<a href="deconnexion.php">Deconnexion</a>
		</p>
	</div>
</div>